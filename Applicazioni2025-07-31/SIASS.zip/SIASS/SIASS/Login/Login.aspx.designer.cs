﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Questo codice è stato generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace SIASS
{


	public partial class Login
	{

		/// <summary>
		/// Controllo form1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm form1;

		/// <summary>
		/// Controllo CredenzialiPanel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Panel CredenzialiPanel;

		/// <summary>
		/// Controllo AvvisoOpzioneRichiestaCredenzialiLabel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label AvvisoOpzioneRichiestaCredenzialiLabel;

		/// <summary>
		/// Controllo UsernameTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox UsernameTextBox;

		/// <summary>
		/// Controllo PasswordTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox PasswordTextBox;

		/// <summary>
		/// Controllo OKButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button OKButton;

		/// <summary>
		/// Controllo MessaggioErroreLabel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label MessaggioErroreLabel;

		/// <summary>
		/// Controllo IntranetHyperLink.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.HyperLink IntranetHyperLink;
	}
}
