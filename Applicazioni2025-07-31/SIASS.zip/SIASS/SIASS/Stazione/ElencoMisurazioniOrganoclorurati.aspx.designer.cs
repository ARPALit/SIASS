﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Questo codice è stato generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace SIASS
{


	public partial class ElencoMisurazioniOrganoclorurati
	{

		/// <summary>
		/// Controllo HeaderStazioneResponsive1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::SIASS.HeaderStazioneResponsive HeaderStazioneResponsive1;

		/// <summary>
		/// Controllo MisurazioniPanel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Panel MisurazioniPanel;

		/// <summary>
		/// Controllo Label1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label1;

		/// <summary>
		/// Controllo DateDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList DateDropDownList;

		/// <summary>
		/// Controllo VisualizzaButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button VisualizzaButton;

		/// <summary>
		/// Controllo ElencoMisurazioniGridView.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.GridView ElencoMisurazioniGridView;

		/// <summary>
		/// Controllo AvvisoLabel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label AvvisoLabel;
	}
}
