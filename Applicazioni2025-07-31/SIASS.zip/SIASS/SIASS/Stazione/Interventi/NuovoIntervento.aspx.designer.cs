﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Questo codice è stato generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace SIASS
{


	public partial class NuovoIntervento
	{

		/// <summary>
		/// Controllo ScriptManager1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.ScriptManager ScriptManager1;

		/// <summary>
		/// Controllo HeaderStazioneResponsive1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::SIASS.HeaderStazioneResponsive HeaderStazioneResponsive1;

		/// <summary>
		/// Controllo ValidationSummary1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.ValidationSummary ValidationSummary1;

		/// <summary>
		/// Controllo Label1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label1;

		/// <summary>
		/// Controllo TipiInterventoDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiInterventoDropDownList;

		/// <summary>
		/// Controllo Label4.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label4;

		/// <summary>
		/// Controllo TipiMatriceDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiMatriceDropDownList;

		/// <summary>
		/// Controllo RequiredFieldValidator1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;

		/// <summary>
		/// Controllo Label3.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label3;

		/// <summary>
		/// Controllo TipiArgomentoDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiArgomentoDropDownList;

		/// <summary>
		/// Controllo RequiredFieldValidator4.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator4;

		/// <summary>
		/// Controllo Label2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label2;

		/// <summary>
		/// Controllo TipiSediDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiSediDropDownList;

		/// <summary>
		/// Controllo RequiredFieldValidator5.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator5;

		/// <summary>
		/// Controllo Label5.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label5;

		/// <summary>
		/// Controllo DataInterventoTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox DataInterventoTextBox;

		/// <summary>
		/// Controllo CalendarExtender1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::AjaxControlToolkit.CalendarExtender CalendarExtender1;

		/// <summary>
		/// Controllo RequiredFieldValidator2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;

		/// <summary>
		/// Controllo RegularExpressionValidator2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator2;

		/// <summary>
		/// Controllo Label16.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label16;

		/// <summary>
		/// Controllo OraInterventoTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox OraInterventoTextBox;

		/// <summary>
		/// Controllo RegularExpressionValidator1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;

		/// <summary>
		/// Controllo Label6.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label6;

		/// <summary>
		/// Controllo TipiRichiedenteDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiRichiedenteDropDownList;

		/// <summary>
		/// Controllo Label7.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label7;

		/// <summary>
		/// Controllo CodiceCampagnaTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox CodiceCampagnaTextBox;

		/// <summary>
		/// Controllo PacchettiGridView.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.GridView PacchettiGridView;

		/// <summary>
		/// Controllo OperatoriUpdatePanel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.UpdatePanel OperatoriUpdatePanel;

		/// <summary>
		/// Controllo OperatoriInterventoGridView.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.GridView OperatoriInterventoGridView;

		/// <summary>
		/// Controllo OperatoriPerInterventoDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList OperatoriPerInterventoDropDownList;

		/// <summary>
		/// Controllo AggiungiOperatoreButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button AggiungiOperatoreButton;

		/// <summary>
		/// Controllo SalvaButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button SalvaButton;

		/// <summary>
		/// Controllo AnnullaButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button AnnullaButton;
	}
}
