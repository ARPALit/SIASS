﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Questo codice è stato generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace SIASS
{


	public partial class ElencoStazioni
	{

		/// <summary>
		/// Controllo ScriptManager1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.ScriptManager ScriptManager1;

		/// <summary>
		/// Controllo UpdatePanel2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.UpdatePanel UpdatePanel2;

		/// <summary>
		/// Controllo Label1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label1;

		/// <summary>
		/// Controllo CodiceIdentificativoDescrizioneTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox CodiceIdentificativoDescrizioneTextBox;

		/// <summary>
		/// Controllo Label3.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label3;

		/// <summary>
		/// Controllo ProvinceDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList ProvinceDropDownList;

		/// <summary>
		/// Controllo Label2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label2;

		/// <summary>
		/// Controllo ComuniDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList ComuniDropDownList;

		/// <summary>
		/// Controllo Label11.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label11;

		/// <summary>
		/// Controllo SitiDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList SitiDropDownList;

		/// <summary>
		/// Controllo Label4.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label4;

		/// <summary>
		/// Controllo TipiReteAppartenenzaDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiReteAppartenenzaDropDownList;

		/// <summary>
		/// Controllo Label6.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label6;

		/// <summary>
		/// Controllo TipiAllestimentoDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiAllestimentoDropDownList;

		/// <summary>
		/// Controllo Label5.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label5;

		/// <summary>
		/// Controllo BaciniDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList BaciniDropDownList;

		/// <summary>
		/// Controllo Label7.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label7;

		/// <summary>
		/// Controllo TipiGrandezzaDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiGrandezzaDropDownList;

		/// <summary>
		/// Controllo Label8.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label8;

		/// <summary>
		/// Controllo CorpiIdriciDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList CorpiIdriciDropDownList;

		/// <summary>
		/// Controllo Label9.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label9;

		/// <summary>
		/// Controllo TipiStazioneDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList TipiStazioneDropDownList;

		/// <summary>
		/// Controllo Label12.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label12;

		/// <summary>
		/// Controllo GestoriDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList GestoriDropDownList;

		/// <summary>
		/// Controllo Label10.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label10;

		/// <summary>
		/// Controllo EsclusaMonitoraggioCheckBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.CheckBox EsclusaMonitoraggioCheckBox;

		/// <summary>
		/// Controllo CercaStazioneButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button CercaStazioneButton;

		/// <summary>
		/// Controllo RimuoviFiltriButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button RimuoviFiltriButton;

		/// <summary>
		/// Controllo NuovaStazioneButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button NuovaStazioneButton;

		/// <summary>
		/// Controllo GestorePanel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Panel GestorePanel;

		/// <summary>
		/// Controllo Label13.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label13;

		/// <summary>
		/// Controllo GestoreCodiceIdentificativoDescrizioneTextBox.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox GestoreCodiceIdentificativoDescrizioneTextBox;

		/// <summary>
		/// Controllo GestoreCercaStazioneButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button GestoreCercaStazioneButton;

		/// <summary>
		/// Controllo UpdatePanel1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.UpdatePanel UpdatePanel1;

		/// <summary>
		/// Controllo StazioniGridView.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.GridView StazioniGridView;

		/// <summary>
		/// Controllo MappaPanel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Panel MappaPanel;

		/// <summary>
		/// Controllo VersioneLabel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label VersioneLabel;

		/// <summary>
		/// Controllo PrivacyHyperLink.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.HyperLink PrivacyHyperLink;
	}
}
