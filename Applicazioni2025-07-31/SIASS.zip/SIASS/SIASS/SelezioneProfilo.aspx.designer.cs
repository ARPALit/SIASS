﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Questo codice è stato generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace SIASS
{


	public partial class SelezioneProfilo
	{

		/// <summary>
		/// Controllo ScriptManager1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.ScriptManager ScriptManager1;

		/// <summary>
		/// Controllo Label4.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label4;

		/// <summary>
		/// Controllo ProfiloAttivoLabel.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label ProfiloAttivoLabel;

		/// <summary>
		/// Controllo Label1.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label1;

		/// <summary>
		/// Controllo ElencoOrganizzazioniDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList ElencoOrganizzazioniDropDownList;

		/// <summary>
		/// Controllo Label2.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label2;

		/// <summary>
		/// Controllo ElencoProfiliDropDownList.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.DropDownList ElencoProfiliDropDownList;

		/// <summary>
		/// Controllo SelezioneProfiloButton.
		/// </summary>
		/// <remarks>
		/// Campo generato automaticamente.
		/// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button SelezioneProfiloButton;

		/// <summary>
		/// Proprietà Master.
		/// </summary>
		/// <remarks>
		/// Proprietà generata automaticamente.
		/// </remarks>
		public new SIASS.MasterPageResponsive Master
		{
			get
			{
				return ((SIASS.MasterPageResponsive)(base.Master));
			}
		}
	}
}
